// src/components/ExerciseLog.jsx

import React, { useState, useEffect } from 'react';
import {
  Typography,
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Snackbar,
  Alert,
  Box,
  Button,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

/**
 * ExerciseLog Component
 *
 * This component displays a log of exercises stored in localStorage.
 * Exercises are grouped by date, and within each date, exercises are listed with their details.
 * Users can delete individual exercises and generate sample data for testing purposes.
 * Additionally, exercises performed on the same date are visually grouped with a red frame.
 */
const ExerciseLog = () => {
  // State to hold the list of exercises fetched from localStorage
  const [exercises, setExercises] = useState([]);

  // Snackbar state variables for providing user feedback
  const [snackbarOpen, setSnackbarOpen] = useState(false); // Controls the visibility of the Snackbar
  const [snackbarMessage, setSnackbarMessage] = useState(''); // Message to display in the Snackbar
  const [snackbarSeverity, setSnackbarSeverity] = useState('success'); // Severity level: 'success' | 'error' | 'warning' | 'info'

  /**
   * useEffect Hook
   *
   * Runs once when the component mounts.
   * - Retrieves exercises from localStorage.
   * - Sorts them by date in descending order.
   */
  useEffect(() => {
    // Retrieve exercises from localStorage or initialize as an empty array if none exist
    const storedExercises = JSON.parse(localStorage.getItem('exercises')) || [];

    // Sort exercises by date in descending order to display the most recent first
    storedExercises.sort((a, b) => new Date(b.date) - new Date(a.date));

    setExercises(storedExercises);
  }, []);

  /**
   * handleDelete Function
   *
   * Deletes an exercise from the log based on its unique identifier.
   *
   * @param {number} id - The unique identifier of the exercise to delete.
   */
  const handleDelete = (id) => {
    // Confirm deletion with the user
    if (window.confirm('Are you sure you want to delete this exercise?')) {
      // Filter out the exercise to be deleted
      const updatedExercises = exercises.filter((exercise) => exercise.id !== id);
      setExercises(updatedExercises);

      // Update the exercises in localStorage
      localStorage.setItem('exercises', JSON.stringify(updatedExercises));

      // Provide success feedback to the user
      setSnackbarMessage('Exercise deleted successfully!');
      setSnackbarSeverity('success');
      setSnackbarOpen(true);
    }
  };

  /**
   * handleCloseSnackbar Function
   *
   * Closes the Snackbar notification.
   *
   * @param {object} event - The event object.
   * @param {string} reason - The reason for closing the Snackbar.
   */
  const handleCloseSnackbar = (event, reason) => {
    if (reason === 'clickaway') {
      return; // Prevents closing the Snackbar when clicking away
    }
    setSnackbarOpen(false); // Closes the Snackbar
  };

  /**
   * generateSampleData Function
   *
   * Generates and stores sample exercise data in localStorage for testing purposes.
   */
  const generateSampleData = () => {
    // Define possible categories and exercise names
    const categories = [
      'Back',
      'Chest',
      'Legs',
      'Arms',
      'Shoulders',
      'Cardio',
      'Abs',
    ];

    const exerciseNames = [
      'Bench Press',
      'Squats',
      'Deadlift',
      'Pull-Ups',
      'Push-Ups',
      'Bicep Curls',
      'Tricep Dips',
      'Shoulder Press',
      'Lunges',
      'Burpees',
      'Rowing',
      'Lat Pulldown',
    ];

    // Define possible set variations
    const setsOptions = [
      [{ weight: 60, reps: 10 }, { weight: 65, reps: 8 }, { weight: 70, reps: 6 }],
      [{ weight: 80, reps: 12 }, { weight: 85, reps: 10 }, { weight: 90, reps: 8 }],
      [{ weight: 100, reps: 5 }, { weight: 105, reps: 5 }, { weight: 110, reps: 5 }],
      [{ weight: 50, reps: 15 }, { weight: 55, reps: 12 }, { weight: 60, reps: 10 }],
      [{ weight: 40, reps: 20 }, { weight: 45, reps: 18 }, { weight: 50, reps: 15 }],
      // Add more set variations if needed
    ];

    const today = new Date(); // Current date
    const sampleExercises = []; // Array to hold sample exercises

    // Generate 20 sample exercises with varying dates, categories, and exercises
    for (let i = 0; i < 20; i++) {
      const date = new Date();
      date.setDate(today.getDate() - i); // Set date to i days ago

      // Randomly select a category and exercise name
      const category = categories[Math.floor(Math.random() * categories.length)];
      const exerciseName = exerciseNames[Math.floor(Math.random() * exerciseNames.length)];

      // Randomly select a set variation
      const sets = setsOptions[Math.floor(Math.random() * setsOptions.length)];

      sampleExercises.push({
        id: Date.now() + i, // Unique identifier based on the current timestamp plus the loop index
        date: date.toISOString().split('T')[0], // Format date as 'YYYY-MM-DD'
        category,
        exerciseName,
        sets,
      });
    }

    // Retrieve existing exercises from localStorage or initialize as an empty array
    const existingExercises = JSON.parse(localStorage.getItem('exercises')) || [];

    // Append the new sample exercises to the existing ones
    const updatedExercises = [...existingExercises, ...sampleExercises];
    setExercises(updatedExercises); // Update the state with the new exercises
    localStorage.setItem('exercises', JSON.stringify(updatedExercises)); // Save back to localStorage

    // Provide success feedback to the user
    setSnackbarMessage('Sample data generated successfully!');
    setSnackbarSeverity('success');
    setSnackbarOpen(true);
  };

  /**
   * groupExercisesByDate Function
   *
   * Groups exercises by their date to facilitate rendering exercises with the same date in a single cell.
   *
   * @returns {Array} - An array of objects where each object represents a date and its associated exercises.
   */
  const groupExercisesByDate = () => {
    // Use a map to group exercises by date
    const grouped = exercises.reduce((acc, exercise) => {
      if (!acc[exercise.date]) {
        acc[exercise.date] = [];
      }
      acc[exercise.date].push(exercise);
      return acc;
    }, {});

    // Convert the grouped object into an array for easier iteration in JSX
    const groupedArray = Object.keys(grouped).map((date) => ({
      date,
      exercises: grouped[date],
    }));

    return groupedArray;
  };

  // Get the grouped exercises by date
  const groupedExercises = groupExercisesByDate();

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Typography variant="h4" gutterBottom>
        Exercise Log
      </Typography>

      {/* Generate Sample Data Button */}
      <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
        <Button variant="contained" color="secondary" onClick={generateSampleData}>
          Generate Sample Data
        </Button>
      </Box>

      {/* Conditional Rendering: Show message if no exercises are recorded */}
      {exercises.length === 0 ? (
        <Typography variant="body1">No exercises recorded yet.</Typography>
      ) : (
        // Table Container with a Paper background and scrollable body
        <TableContainer component={Paper} sx={{ maxHeight: '80vh' }}>
          <Table stickyHeader aria-label="exercise log table">
            {/* Table Head: Defines the column headers */}
            <TableHead>
              <TableRow>
                <TableCell>Date</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Exercise Name</TableCell>
                <TableCell>Sets</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>

            {/* Table Body: Renders the exercises grouped by date */}
            <TableBody>
              {groupedExercises.map((group) => (
                // Iterate over each date group
                group.exercises.map((exercise, index) => (
                  <TableRow key={exercise.id} hover>
                    {/* Render the Date cell only for the first exercise in the group */}
                    {index === 0 && (
                      <TableCell
                        rowSpan={group.exercises.length}
                        sx={{
                            border: '2px solid #ff1744', // Adds a red border around the Date cell
                        }}
                      >
                        {exercise.date}
                      </TableCell>
                    )}
                    {/* Category Cell */}
                    <TableCell>{exercise.category}</TableCell>
                    {/* Exercise Name Cell */}
                    <TableCell>{exercise.exerciseName}</TableCell>
                    {/* Sets Cell: Lists all sets for the exercise */}
                    <TableCell>
                      {exercise.sets.map((set, setIndex) => (
                        <Box key={setIndex} sx={{ mb: 0.5 }}>
                          Set {setIndex + 1}: {set.weight} kg x {set.reps} reps
                        </Box>
                      ))}
                    </TableCell>
                    {/* Actions Cell: Contains the delete button */}
                    <TableCell align="center">
                      <IconButton
                        color="error" // Sets the color of the button to indicate a destructive action
                        onClick={() => handleDelete(exercise.id)} // Calls handleDelete with the exercise's id
                        aria-label="delete exercise" // Accessibility label for screen readers
                      >
                        <DeleteIcon /> {/* Delete icon */}
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {/* Snackbar Component for User Feedback */}
      <Snackbar
        open={snackbarOpen} // Controls visibility based on state
        autoHideDuration={4000} // Automatically hides after 4 seconds
        onClose={handleCloseSnackbar} // Function to handle closing the Snackbar
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }} // Positions the Snackbar at the bottom-center
      >
        <Alert
          onClose={handleCloseSnackbar} // Allows the Snackbar to be closed manually
          severity={snackbarSeverity} // Sets the severity of the Alert
          sx={{ width: '100%' }} // Makes the Alert take the full width of its container
        >
          {snackbarMessage} {/* Displays the message */}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default ExerciseLog;
