// src/components/AddExercise.jsx
import React, { useState, useEffect } from 'react';
import {
  Typography,
  Container,
  TextField,
  Button,
  Box,
  IconButton,
  MenuItem,
  Grid,
  Snackbar,
  Alert,
} from '@mui/material';
import { AddCircleOutline, RemoveCircleOutline } from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs'; // Using Day.js adapter
import dayjs from 'dayjs'; // Import Day.js

const categories = [
  'Back',
  'Chest',
  'Legs',
  'Arms',
  'Shoulders',
  'Abs',
];

const AddExercise = () => {
  const [date, setDate] = useState(dayjs()); // Initialize with dayjs
  const [category, setCategory] = useState('');
  const [exerciseName, setExerciseName] = useState('');
  const [sets, setSets] = useState([
    { weight: '', reps: '' },
  ]);

  // Snackbar state for user feedback
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success'); // 'success' | 'error' | 'warning' | 'info'

  // Function to handle adding a new set
  const handleAddSet = () => {
    setSets([...sets, { weight: '', reps: '' }]);
  };

  // Function to handle removing a set
  const handleRemoveSet = (index) => {
    const newSets = sets.filter((_, idx) => idx !== index);
    setSets(newSets);
  };

  // Function to handle input changes for sets
  const handleSetChange = (index, field, value) => {
    const newSets = sets.map((set, idx) => {
      if (idx === index) {
        return { ...set, [field]: value };
      }
      return set;
    });
    setSets(newSets);
  };

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate form fields
    if (!date || !category || !exerciseName) {
      setSnackbarMessage('Please fill in all required fields.');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
      return;
    }

    for (let i = 0; i < sets.length; i++) {
      const { weight, reps } = sets[i];
      if (!weight || !reps) {
        setSnackbarMessage(`Please fill in weight and reps for set ${i + 1}.`);
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
        return;
      }
    }

    // Create exercise object
    const exercise = {
      id: Date.now(), // Unique identifier
      date: date.format('YYYY-MM-DD'), // Format: YYYY-MM-DD
      category,
      exerciseName,
      sets,
    };

    // Retrieve existing exercises from localStorage
    const existingExercises = JSON.parse(localStorage.getItem('exercises')) || [];

    // Add the new exercise
    existingExercises.push(exercise);

    // Save back to localStorage
    localStorage.setItem('exercises', JSON.stringify(existingExercises));

    // Reset the form
    setDate(dayjs());
    setCategory('');
    setExerciseName('');
    setSets([{ weight: '', reps: '' }]);

    // Provide user feedback
    setSnackbarMessage('Exercise added successfully!');
    setSnackbarSeverity('success');
    setSnackbarOpen(true);
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Add Exercise
        </Typography>
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <Grid container spacing={3}>
            {/* Date Picker */}
            <Grid item xs={12} sm={6}>
              <DatePicker
                label="Date"
                value={date}
                onChange={(newValue) => setDate(newValue)}
                renderInput={(params) => <TextField {...params} required fullWidth />}
              />
            </Grid>

            {/* Category Select */}
            <Grid item xs={12} sm={6}>
              <TextField
                select
                label="Category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                required
                fullWidth
              >
                {categories.map((option) => (
                  <MenuItem key={option} value={option}>
                    {option}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>

            {/* Exercise Name */}
            <Grid item xs={12}>
              <TextField
                label="Exercise Name"
                value={exerciseName}
                onChange={(e) => setExerciseName(e.target.value)}
                required
                fullWidth
              />
            </Grid>

            {/* Sets */}
            <Grid item xs={12}>
              <Typography variant="h6">Sets</Typography>
              {sets.map((set, index) => (
                <Box key={index} sx={{ display: 'flex', alignItems: 'center', mt: 2 }}>
                  {/* Weight */}
                  <TextField
                    label={`Set ${index + 1} Weight (kg)`}
                    type="number"
                    value={set.weight}
                    onChange={(e) => handleSetChange(index, 'weight', e.target.value)}
                    required
                    sx={{ mr: 2, flex: 1 }}
                  />

                  {/* Reps */}
                  <TextField
                    label={`Set ${index + 1} Reps`}
                    type="number"
                    value={set.reps}
                    onChange={(e) => handleSetChange(index, 'reps', e.target.value)}
                    required
                    sx={{ mr: 2, flex: 1 }}
                  />

                  {/* Remove Set */}
                  {sets.length > 1 && (
                    <IconButton
                      color="secondary"
                      onClick={() => handleRemoveSet(index)}
                      aria-label="remove set"
                    >
                      <RemoveCircleOutline />
                    </IconButton>
                  )}
                </Box>
              ))}
              <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
                <IconButton
                  sx={{ color: 'white', fontSize: '3rem' }}
                  onClick={() => handleAddSet()}
                  aria-label="add set"
                >
                  <AddCircleOutline fontSize="inherit" />
                </IconButton>
              </Box>
            </Grid>

            {/* Submit Button */}
            <Grid item xs={12}>
              <Button type="submit" variant="contained" color="primary">
                Save Exercise
              </Button>
            </Grid>
          </Grid>
        </Box>

        {/* Snackbar for User Feedback */}
        <Snackbar
          open={snackbarOpen}
          autoHideDuration={6000}
          onClose={() => setSnackbarOpen(false)}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert
            onClose={() => setSnackbarOpen(false)}
            severity={snackbarSeverity}
            sx={{ width: '100%' }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Container>
    </LocalizationProvider>
  );
};

export default AddExercise;
