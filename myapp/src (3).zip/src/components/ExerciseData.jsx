// src/components/ExerciseData.jsx
import React, { useState, useEffect } from 'react';
import {
  Typography,
  Container,
  Box,
  TextField,
  IconButton,
  Tooltip,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Button,
  Snackbar,
  Alert,
} from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import PieActiveArc from './PieActiveArc.jsx';
import { Link } from 'react-router-dom';

const ExerciseData = () => {
  const [userInfo, setUserInfo] = useState(null);
  const [exercises, setExercises] = useState([]);

  // States for Categories and Exercises
  const [categories, setCategories] = useState([]); // Unique categories
  const [selectedCategory, setSelectedCategory] = useState(''); // User-selected category

  const [exercisesList, setExercisesList] = useState([]); // Exercises based on category
  const [selectedExerciseName, setSelectedExerciseName] = useState(''); // User-selected exercise name

  const [exerciseDates, setExerciseDates] = useState([]); // Dates based on exercise
  const [selectedExerciseDate, setSelectedExerciseDate] = useState(null); // User-selected date

  // States for 1RM Calculation
  const [oneRM, setOneRM] = useState(null);

  // States for Relative Strength
  const [relativeStrength, setRelativeStrength] = useState(null);

  // States for Workout Distribution
  const [selectedMonth, setSelectedMonth] = useState(dayjs());
  const [workoutDistribution, setWorkoutDistribution] = useState([]);

  // Snackbar states for user feedback
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success'); // 'success' | 'error' | 'warning' | 'info'

  // New State Variable to Store Exercise Entry
  const [selectedExerciseEntry, setSelectedExerciseEntry] = useState(null);

  // Fetch user info and exercises from localStorage on component mount
  useEffect(() => {
    try {
      const storedUserInfo = JSON.parse(localStorage.getItem('userInfo'));
      setUserInfo(storedUserInfo);
    } catch (error) {
      console.error('Failed to parse userInfo from localStorage:', error);
      setUserInfo(null);
      setSnackbarMessage('Failed to load user information.');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }

    try {
      const storedExercises = JSON.parse(localStorage.getItem('exercises')) || [];
      setExercises(storedExercises);

      // Extract unique categories
      const uniqueCategories = [
        ...new Set(storedExercises.map((ex) => ex.category)),
      ];
      setCategories(uniqueCategories);
    } catch (error) {
      console.error('Failed to parse exercises from localStorage:', error);
      setExercises([]);
      setCategories([]);
      setSnackbarMessage('Failed to load exercises data.');
      setSnackbarSeverity('error');
      setSnackbarOpen(true);
    }
  }, []);

  // Update exercises list based on selected category
  useEffect(() => {
    if (selectedCategory) {
      const filteredExercises = exercises.filter(
        (ex) => ex.category === selectedCategory
      );

      // Extract unique exercise names within the selected category
      const uniqueExercises = [
        ...new Set(filteredExercises.map((ex) => ex.exerciseName)),
      ];
      setExercisesList(uniqueExercises);

      // Reset selected exercise and date
      setSelectedExerciseName('');
      setExerciseDates([]);
      setSelectedExerciseDate(null);
      setSelectedExerciseEntry(null);
      setOneRM(null);
      setRelativeStrength(null);
    } else {
      setExercisesList([]);
      setSelectedExerciseName('');
      setExerciseDates([]);
      setSelectedExerciseDate(null);
      setSelectedExerciseEntry(null);
      setOneRM(null);
      setRelativeStrength(null);
    }
  }, [selectedCategory, exercises]);

  // Update exercise dates based on selected exercise
  useEffect(() => {
    if (selectedExerciseName) {
      const filteredExercises = exercises.filter(
        (ex) =>
          ex.category === selectedCategory && ex.exerciseName === selectedExerciseName
      );

      // Extract unique dates for the selected exercise
      const dates = filteredExercises.map((ex) => ex.date);

      // Sort dates in descending order to find the newest
      const sortedDates = dates.sort((a, b) => (a < b ? 1 : -1));
      setExerciseDates(sortedDates);

      // Set default date to the newest
      if (sortedDates.length > 0) {
        setSelectedExerciseDate(dayjs(sortedDates[0]));
      } else {
        setSelectedExerciseDate(null);
        setSelectedExerciseEntry(null);
        setOneRM(null);
        setRelativeStrength(null);
      }
    } else {
      setExerciseDates([]);
      setSelectedExerciseDate(null);
      setSelectedExerciseEntry(null);
      setOneRM(null);
      setRelativeStrength(null);
    }
  }, [selectedExerciseName, selectedCategory, exercises]);

  // Handle 1RM and Relative Strength calculation based on selected date
  useEffect(() => {
    if (selectedExerciseDate && selectedExerciseName) {
      const formattedDate = selectedExerciseDate.format('YYYY-MM-DD');
      const exerciseEntry = exercises.find(
        (ex) =>
          ex.category === selectedCategory &&
          ex.exerciseName === selectedExerciseName &&
          ex.date === formattedDate
      );

      setSelectedExerciseEntry(exerciseEntry || null);

      if (exerciseEntry) {
        // Calculate 1RM using Epley Formula for each set and take the maximum
        const calculatedOneRM = exerciseEntry.sets.reduce((max, set) => {
          const currentOneRM = set.weight * (1 + 0.0333 * set.reps);
          return currentOneRM > max ? currentOneRM : max;
        }, 0);
        setOneRM(calculatedOneRM.toFixed(2));

        // Calculate Relative Strength
        if (userInfo && userInfo.weight) {
          const relStrength = calculatedOneRM / userInfo.weight;
          setRelativeStrength(relStrength.toFixed(2));
        } else {
          setRelativeStrength(null);
        }

        // Optionally, show a success snackbar
        setSnackbarMessage('1RM and Relative Strength calculated successfully!');
        setSnackbarSeverity('success');
        setSnackbarOpen(true);
      } else {
        setOneRM(null);
        setRelativeStrength(null);
        setSnackbarMessage('No exercise found for the selected date.');
        setSnackbarSeverity('error');
        setSnackbarOpen(true);
      }
    } else {
      setSelectedExerciseEntry(null);
      setOneRM(null);
      setRelativeStrength(null);
    }
  }, [selectedExerciseDate, selectedExerciseName, selectedCategory, exercises, userInfo]);

  // Handle selection of month to calculate workout distribution
  useEffect(() => {
    if (selectedMonth) {
      const month = selectedMonth.month(); // 0-indexed
      const year = selectedMonth.year();

      const filteredExercises = exercises.filter((ex) => {
        const exDate = dayjs(ex.date);
        return exDate.month() === month && exDate.year() === year;
      });

      const categoryCount = {};
      filteredExercises.forEach((ex) => {
        categoryCount[ex.category] = (categoryCount[ex.category] || 0) + 1;
      });

      const distributionData = Object.keys(categoryCount).map((category) => ({
        label: category,
        value: categoryCount[category],
      }));

      setWorkoutDistribution(distributionData);
    } else {
      setWorkoutDistribution([]);
    }
  }, [selectedMonth, exercises]);

  // Handle Snackbar Closure
  const handleCloseSnackbar = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Exercise Data
        </Typography>

        {/* BMI Section */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Body Mass Index (BMI)
            <Tooltip
              title={
                <Typography variant="body2">
                  BMI is a measure of body fat based on height and weight. It is calculated as:
                  <br />
                  <strong>BMI = Weight (kg) / (Height (m))²</strong>
                </Typography>
              }
              arrow
            >
              <IconButton size="small" sx={{ ml: 1 }} aria-label="BMI Explanation">
                <InfoIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Typography>
          {userInfo && userInfo.height && userInfo.weight ? (
            <Typography variant="body1">
              Your BMI is:{' '}
              <strong>
                {(
                  userInfo.weight /
                  Math.pow(userInfo.height / 100, 2)
                ).toFixed(2)}
              </strong>
            </Typography>
          ) : (
            <Typography variant="body1" color="text.secondary">
              Please update your{' '}
              <Button component={Link} to="/user-info">
                user information
              </Button>{' '}
              to view BMI.
            </Typography>
          )}
        </Box>

        {/* 1RM Calculator Section */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            One Rep Max (1RM) Calculator
            <Tooltip
              title={
                <Typography variant="body2">
                  1RM estimates the maximum weight you can lift for one repetition. It is calculated using the Epley Formula:
                  <br />
                  <strong>1RM = Weight × (1 + 0.0333 × Reps)</strong>
                </Typography>
              }
              arrow
            >
              <IconButton size="small" sx={{ ml: 1 }} aria-label="1RM Explanation">
                <InfoIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Typography>

          {/* Select Category */}
          <Box sx={{ mt: 2, mb: 2 }}>
            <FormControl fullWidth>
              <InputLabel id="category-label">Select Category</InputLabel>
              <Select
                labelId="category-label"
                label="Select Category"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                disabled={categories.length === 0}
              >
                {categories.length > 0 ? (
                  categories.map((category) => (
                    <MenuItem key={category} value={category}>
                      {category}
                    </MenuItem>
                  ))
                ) : (
                  <MenuItem value="" disabled>
                    No categories available
                  </MenuItem>
                )}
              </Select>
            </FormControl>
          </Box>

          {/* Select Exercise */}
          {selectedCategory && (
            <Box sx={{ mt: 2, mb: 2 }}>
              <FormControl fullWidth>
                <InputLabel id="exercise-label">Select Exercise</InputLabel>
                <Select
                  labelId="exercise-label"
                  label="Select Exercise"
                  value={selectedExerciseName}
                  onChange={(e) => setSelectedExerciseName(e.target.value)}
                  disabled={exercisesList.length === 0}
                >
                  {exercisesList.length > 0 ? (
                    exercisesList.map((exercise) => (
                      <MenuItem key={exercise} value={exercise}>
                        {exercise}
                      </MenuItem>
                    ))
                  ) : (
                    <MenuItem value="" disabled>
                      No exercises available
                    </MenuItem>
                  )}
                </Select>
              </FormControl>
            </Box>
          )}

          {/* Select Date */}
          {selectedExerciseName && (
            <Box sx={{ mt: 2, mb: 2 }}>
              {exerciseDates.length > 0 ? (
                <DatePicker
                  label="Select Date"
                  value={selectedExerciseDate}
                  onChange={(newValue) => setSelectedExerciseDate(newValue)}
                  renderInput={(params) => <TextField {...params} fullWidth />}
                  disableFuture
                  minDate={dayjs('2000-01-01')}
                />
              ) : (
                <Typography variant="body2" color="text.secondary">
                  No dates available for the selected exercise.
                </Typography>
              )}
            </Box>
          )}

          {/* Display 1RM and Relative Strength */}
          {selectedExerciseName && selectedExerciseDate && (
            selectedExerciseEntry ? (
              <Box sx={{ mt: 2 }}>
                <Typography variant="body1">
                  <strong>Exercise:</strong> {selectedExerciseEntry.exerciseName} ({selectedExerciseEntry.category})
                </Typography>
                <Typography variant="body1">
                  <strong>1RM:</strong> {oneRM} kg
                </Typography>
                {relativeStrength && (
                  <Typography variant="body1">
                    <strong>Relative Strength:</strong> {relativeStrength}{' '}
                    <Tooltip
                      title={
                        <Typography variant="body2">
                          Relative Strength is calculated as your One Rep Max (1RM) divided by your body weight.
                          <br />
                          <strong>Relative Strength = 1RM / Body Weight</strong>
                        </Typography>
                      }
                      arrow
                    >
                      <IconButton size="small" sx={{ ml: 1 }} aria-label="Relative Strength Explanation">
                        <InfoIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Typography>
                )}
              </Box>
            ) : (
              <Typography variant="body1" color="text.secondary">
                No exercise found for the selected date.
              </Typography>
            )
          )}
        </Box>

        {/* Workout Distribution by Category Section */}
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>
            Workout Distribution by Category
            <Tooltip
              title={
                <Typography variant="body2">
                  This pie chart represents the distribution of your workouts across different categories for the selected month.
                </Typography>
              }
              arrow
            >
              <IconButton size="small" sx={{ ml: 1 }} aria-label="Workout Distribution Explanation">
                <InfoIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Typography>

          {/* Select Month */}
          <Box sx={{ mt: 2, mb: 2 }}>
            <DatePicker
              views={['year', 'month']}
              label="Select Month"
              minDate={dayjs('2000-01-01')}
              maxDate={dayjs()}
              value={selectedMonth}
              onChange={(newValue) => setSelectedMonth(newValue)}
              renderInput={(params) => <TextField {...params} fullWidth />}
            />
          </Box>

          {/* Display Pie Chart */}
          {workoutDistribution.length > 0 ? (
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
              <PieActiveArc data={workoutDistribution} />
            </Box>
          ) : (
            <Typography variant="body1" color="text.secondary">
              No workout data available for the selected month.
            </Typography>
          )}
        </Box>

        {/* Snackbar for User Feedback */}
        <Snackbar
          open={snackbarOpen}
          autoHideDuration={6000}
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
        >
          <Alert
            onClose={handleCloseSnackbar}
            severity={snackbarSeverity}
            sx={{ width: '100%' }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Container>
    </LocalizationProvider>
  );
};

export default ExerciseData;
